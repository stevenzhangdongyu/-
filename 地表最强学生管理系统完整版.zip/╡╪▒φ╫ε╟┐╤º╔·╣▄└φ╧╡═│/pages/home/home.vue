<template>
	<view class="page">
		<view>			
			<view class="page-block super-hot">
				
				<view class="hot-title-wapper">
					<image src= "../../static/校园导航.png"class="hot-ico"></image>
					<view class="hot-title">
						校园风光			
					</view>
				</view>
				
			</view>
			<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" class="carousel">
			
	<!-- 		<swiper-item v-for="carousel in carouselList">
				<image
				 :src="carousel.image" 
				class="carousel"></image>
			</swiper-item> -->
			
				<swiper-item>
					<image src="../../static/carousel/0.webp" class="carousel"></image>
				</swiper-item>
				<swiper-item>
					<image src="../../static/carousel/1.webp"class="carousel"></image>
				</swiper-item>
				<swiper-item>
					<image src="../../static/carousel/3.webp" class="carousel"></image>
				</swiper-item>
				<swiper-item>
					<image src="../../static/carousel/4.webp" class="carousel"></image>
				</swiper-item>
				<swiper-item>
					<image src="../../static/carousel/5.webp" class="carousel"></image>
				</swiper-item>
			</swiper>
		</view>
		
		<view class="page-block super-hot">
			<view class="hot-title-wapper">
				<image src="../../static/校园风光.png"class="hot-ico"></image>
				<view class="hot-title">
					媒体轻院					
				</view>
			</view>
		</view>
		<view>
			<video id="myVideo" src="https://www.gzqy.cn/__local/4/00/9E/BE10FAC6752BEC616155FFD4320_C1C65BAC_232A399B.mp4?e=.mp4"
			 @error="videoErrorCallback" :danmu-list="danmuList" enable-danmu danmu-btn controls class="video-size" poster="https://www.gzqy.cn/__local/4/BD/FD/33AD40DA651C2652C74D6878A08_A528F667_D512F.png">
			 </video>
		</view>
		
		
	</view>
</template>

<script>
	
	// import common from "../../common/common.js";
	
	
	export default {
		data() {
			return {
				// carouselList:[]
				
			}
		},
		onLoad() {
			// //获取common.js中的服务器地址
			// var serverUrl=common.serverUrl;
			
			// uni.request{
			// 	url:serverUrl+'/index/carousel/list',
			// 	method:"POST",
			// 	success:(res)=>{
			// 		console.log(rrs.data);
			// 		if(res.data.status==200){
			// 			var carouselList=res.data.data;
			// 		this.carouselList=carouselList
						
			// 		}
					
			// 		this.text='request success';
			// 	}
			// }
			

		},
		methods: {
			
			

		}
	}
</script>


<style>
	.page{
		background-color: #f7f7f7;
	}
	.carousel
	{
		width: 100%;
		height: 500upx;
	}
	.page-block
	{
		background-color: #ffffff;
	}
	.super-hot{
		margin-top: 12upx;
		padding: 20upx;
	}
	.hot-title-wapper{
		display: flex;
		flex-direction: row;
	}
	.hot-ico{
		width: 50upx;
		height:50upx;
		margin-top: 15upx;
	}
	.hot-title{
		font-size: 20px;
		margin-left: 20upx;
		font-weight: bold;
	}
	
	.video-size{
		width: 100%;
	}
</style>
