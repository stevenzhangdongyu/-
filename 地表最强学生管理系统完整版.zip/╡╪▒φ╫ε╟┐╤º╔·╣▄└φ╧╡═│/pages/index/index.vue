<template>
	<view class="container">
		<!-- 设置背景图片 -->
		<image class="bg-img" src="/static/background1.png"></image>
		<view class="content"></view>
		<!-- 校徽 -->
		<view class="logo-size">
			<image src="/static/test1.png" class="img-size" mode="heightFix"></image>
		</view>
		<!-- 学号输入 -->
		<view class="login-input-box">
			<uni-easyinput prefixIcon="person-filled" placeholder="请输入学号" type="number" maxlength="8"
				v-model="user_number" @input="inputData1">
			</uni-easyinput>
		</view>
		<br>
		<!-- 密码输入 -->
		<view class="login-input-psw">
			<uni-easyinput prefixIcon="locked-filled" placeholder="请输入密码" type="password" v-model="user_password"
				@input="inputData2">
			</uni-easyinput>
		</view>
		<!-- 登录按钮以及注册和忘记密码 -->
		<view class="button-sp-area">
			<button type="primary" @click="login">登录</button>
		</view>
		<view>
			<view class="register-forget">
				<view><button class="register-forget" @click="register">注册账号</button></view>
				<view class="one">|</view>
				<navigator url="/pages/fgt_psw/page3">
					<view><button class="register-forget">忘记密码</button></view>
				</navigator>

			</view>
		</view>
	</view>

</template>




<script>
	export default {
		data() {
			return {
				user_number: "",
				user_password: ""
			}
		},
		methods: {
			register: function() {
				uni.request({
					url: 'http://127.0.0.1:10086/user/registerService',
					success(res) {
						uni.navigateTo({
							url: '/pages/register/register1?account_number=' + res.data['account_number'],
						})
					}
				})
			},
			inputData1(e) {
				this.user_number = e.detail.value
			},
			inputData2(e) {
				this.user_password = e.detail.value
			},
			login:function() {
				// 向后端发送数据
				uni.request({
					url: 'http://127.0.0.1:10086/user/loginService',
					data: {
						//根据后端接口写
						account_number: this.user_number,
						psw: this.user_password
					},
					success: (res) => {
						if (res.data['code'] == 1) {
							uni.showToast({
								title: '登录成功',
								duration: 1000
							});

							setTimeout(() => {
								uni.setStorageSync('option',{account_number:res.data['data']['account_number'],
															major:res.data['data']['major'],
															name:res.data['data']['name'],
															gender:res.data['data']['gender'],
															home:res.data['data']['home'],
															psw:res.data['data']['psw'],
															politicalFace:res.data['data']['politicalFace'],
															})
								uni.switchTab({
									url: '/pages/me/me',
									success: (res) => {
										console.log(res)
									},
								})
							},1000)

						} else {
							uni.showToast({
								title: '登录失败',
								icon: "error",
								duration: 1000
							});

						}

					},
					fail: () => {
						uni.showToast({
							title: '登录失败',
							icon: "error"
						});

					}
				})
			}
		}
	}
</script>

<style>
	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}

	.logo-size {
		margin-top: 70px;
		text-align: center;
		margin-bottom: 80px;

	}

	.img-size {
		width: 200px;
		height: 200px;
	}

	.login-input-box {
		width: 65%;
		margin: auto;
	}

	.login-input-psw {
		width: 65%;
		margin: auto;
		margin-bottom: 30px;
	}

	.button-sp-area {
		margin: 0 auto;
		width: 65%;
	}

	button::after {
		border: none;
	}

	.register-forget {
		font-size: 14px;
		padding: 0px;
		margin: 5px;
		display: flex;
		flex-direction: row;
		justify-content: center;
		background-color: transparent;

	}

	.one {
		margin-top: 12px;
	}
</style>
