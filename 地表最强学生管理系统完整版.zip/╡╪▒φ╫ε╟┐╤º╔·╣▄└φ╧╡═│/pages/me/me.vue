<template>
	<view class="self_form">
		<view class="self">
			<image src="../../static/编号.png" class="icon"></image>
			<view class="self-message">学号：{{this.account_number_}}</view>
		</view>
		<view class="self">
			<image src="../../static/icon/职业用.png" class="icon"></image>
			<view class="self-message">专业：{{this.major_}}</view>
		</view>

		<view class="self">
			<image src="../../static/icon/姓名.png" class="icon"></image>
			<view class="self-message">姓名：{{this.name_}}</view>
		</view>

		<view class="self">
			<image src="../../static/icon/性别.png" class="icon"></image>
			<view class="self-message">性别：{{this.gender_}}</view>
		</view>
		<view class="self">
			<image src="../../static/icon/城市.png" class="icon"></image>
			<view class="self-message">籍贯：{{this.home_}}</view>
		</view>
		<view class="self">
			<image src="../../static/icon/群众.png" class="icon"></image>
			<view class="self-message">政治面貌：{{this.politicalFace_}}</view>
		</view>

		<view class="button_set">
			<!-- <view class="self_form_dl">
								<button @click="delete_">注销账号</button>
							</view> -->
			<view><button class="button1" @click="change">修改密码</button></view>
			<view><button class="button2" @click="change2">修改信息</button></view>
		</view>

		<view class="button3_set">
			<button class="button3" @click="delete_">注销账号</button>
		</view>
		<view class="button3_set">
			<button class="button3" @click="return_">退出登录</button>
		</view>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				account_number_: '',
				major_: '',
				name_: '',
				gender_: '',
				home_: '',
				psw_: '',
				politicalFace_: ''
			}

		},
		// onLoad(option) {
		// 	console.log(option)
		// },
		onShow() {
			let option=uni.getStorageSync('option');
			this.account_number_=option.account_number;
			this.major_=option.major;
			this.name_=option.name;
			this.gender_=option.gender;
			this.home_=option.home;
			this.psw_=option.psw;
			this.politicalFace_=option.politicalFace;
		},

		methods: {

			delete_() {
				 let this_ = this
				 console.log(this_.account_number_)
				let yes = false
				uni.showModal({
					title: '提示',
					content: '确定注销吗？',
					
					success: function(res) {
						let this__=this_
						console.log(this__.account_number_)
						if (res.confirm) {
							console.log('用户点击确定');
							yes = true

							uni.request({
								url: 'http://127.0.0.1:10086/user/deleteService?account_number='+this__.account_number_,
								// data: {
								// 	account_number: this__.account_number
								// },
								success(res) {
									if (res.data['code'] == 1) {

										uni.navigateTo({
											url: '/pages/index/index'
										})
									}
								}
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			},
			change() {
				uni.navigateTo({
					url: '/pages/psw_change/psw_change?psw='+this.psw_+'&account_number='+this.account_number_

				})
			},
			change2() {
				uni.navigateTo({
					url: '/pages/modify/modify?account_number=' + this.account_number_ + '&name=' + this.name_ +
						'&home=' + this.home_ + '&major=' + this.major_ + '&gender=' + this.gender_ +
						'&politicalFace=' + this.politicalFace_
				})
			},
			return_(){
				uni.navigateTo({
					url:'/pages/index/index'
				})
			}

		}
	}
</script>
<style>
	.self_form {
		width: 100%;
		height: auto;
		box-sizing: border-box;
		padding: 20upx 8%;
	}

	.self{
		width: 100%;
		height: 15px;
		display: flex;
		flex-direction: row;
		border-bottom: 1px #eee solid;
		padding: 40upx 0px;
	}
	

	
	.button_set {
		justify-content: center;
		display: flex;
		flex-direction: row;
		margin-top: 20px;
		padding: 10px;
	}

	.button1 {
		font-size: 20px;
		margin-right: 30px;
		border-radius: 10%;
		background-color: skyblue;

	}

	.button2 {
		font-size: 20px;
		border-radius: 10%;
		background-color: skyblue;

	}

	.button3::after {
		border: none;

	}

	.button3 {
		font-size: 15px;
		width: 32%;
		background-color: transparent;
	}

	.button3_set {
		width: 100%;

	}

	.icon {
		width: 50upx;
		height: 50upx;
		margin-top: 2rpx;
	}
</style>
