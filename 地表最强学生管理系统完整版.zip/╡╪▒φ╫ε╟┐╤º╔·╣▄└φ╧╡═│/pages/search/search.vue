<template>
	<view>
		<view class="charts-box">
			<qiun-data-charts type="pie" :opts="opts_pie" :chartData="chartData_pie" />
		</view>
		<view class="charts-box">
			<qiun-data-charts type="column" :opts="opts_column" :chartData="chartData_column" />
		</view>

	</view>
</template>

<script>
	import qiunDataCharts from '../../qiun-data-charts/components/qiun-data-charts/qiun-data-charts.vue';
	import uCharts from '../../qiun-data-charts/js_sdk/u-charts/u-charts.js';
	export default {
		components: {
			qiunDataCharts,
			//qiunloading

		},
		data() {
			return {
				chartData_pie: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['pie'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts_pie: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					extra: {
						pie: {
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: false,
							borderWidth: 3,
							borderColor: "#FFFFFF"
						}
					}
				},
				chartData_column: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['column'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts_column: {
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 5],
					legend: {},
					xAxis: {
						disableGrid: true
					},
					yAxis: {
						data: [{
							min: 0
						}]
					},
					extra: {
						column: {
							type: "group",
							width: 30,
							activeBgColor: "#000000",
							activeBgOpacity: 0.08
						}
					}
				}
			};
		},
		onLoad() {
			this.getServerData_pie();
			this.getServerData_column();

		},
		methods: {
			getServerData_column() {
				//模拟从服务器获取数据时的延时
				setTimeout(() => {
				  //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
				  let res = {
				      categories: ["2016","2017","2018","2019","2020","2021"],
				      series: [
				        {
				          name: "目标值",
				          data: [35,36,31,33,13,34]
				        }
				      ]
				    };
				  this.chartData_column = JSON.parse(JSON.stringify(res));
				}, 500);
				// let _this = this
				// uni.request({
				// 	url: 'http://localhost:10086/user/major',
				// 	success(res) {
				// 		setTimeout(() => {

				// 			_this.chartData_column = JSON.parse(JSON.stringify(res.data))
				// 		}, 500);

				// 	}
				// })
			},

			getServerData_pie() {
				// 模拟从服务器获取数据时的延时
				setTimeout(() => {
				  //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
				  let res = {
				      series: [
				        {
				          data: [{"name":"一班","value":50},{"name":"二班","value":30},{"name":"三班","value":20},{"name":"四班","value":18},{"name":"五班","value":8}]
				        }
				      ]
				    };
				  this.chartData_pie = JSON.parse(JSON.stringify(res));
				}, 500);
				// let _this = this
				// uni.request({
				// 	url: 'http://localhost:10086/user/politicalFace',
				// 	success(res) {
				// 		setTimeout(() => {
				// 			let data1 = {
				// 				series: [{
				// 					data: res.data
				// 				}]
				// 			}
				// 			_this.chartData_pie = JSON.parse(JSON.stringify(data1))
				// 		}, 500);

				// 	}
				// })
			},
		}
	};
</script>

<style>
	.charts-box {
		width: 100%;
		height: 300px;
	}
</style>
