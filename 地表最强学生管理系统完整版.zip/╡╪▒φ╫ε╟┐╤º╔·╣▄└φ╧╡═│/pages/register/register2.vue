<template>

	<view class="container">

		<image class="bg-img" src="/static/bg.png"></image>
		<view class="content"></view>
		<view class="all-size">
			<form @submit="formSubmit">
				<view class="uni-common-mt">
					<view class="login_from_input">
						<view class="title">专业大类：</view>
						<picker mask-style="background:#ffffff00;z-index:0;" @change="bindPickerChange1" :value="index1"
							:range="array1">
							<view class="uni-input-picker">{{array1[index1]}}</view>
						</picker>
					</view>
				</view>

				<view class="title">政治面貌：</view>
				<picker @change="bindPickerChange3" :value="index3" :range="array3">
					<view class="uni-input-picker">{{array3[index3]}}</view>
				</picker>
				<view class="title">所在城市：</view>
				<picker @change="bindPickerChange2" :value="index2" :range="array2">
					<view class="uni-input-picker">{{array2[index2]}}</view>
				</picker>
				<view class="title">性别：</view>
				<view class="gender">
					<radio-group name="gender" @change="in_gender">
						<label>
							<radio value="男" /><text>男</text>
						</label>
						<label>
							<radio value="女" /><text>女</text>
						</label>
					</radio-group>
				</view>
				<!-- </view> -->
				<br>
				<view class="register-next-button">
					<button form-type="submit" @click="finish" type="primary">下一步</button>
				</view>
			</form>
		</view>

	</view>
</template>

<script>
	export default {
		onLoad(option) {
			this.account_number_ = option.account_number
			this.psw_ = option.psw
			this.name_ = option.name
		},
		data() {
			return {
				name_: '',
				psw_: '',
				account_number_: '',
				politicalFace_: '群众',
				home_: '',
				major_: '',
				gender_: '',
				array1: [
					'请选择',
					'旅游大类', '财经大类', '制造大类', '土建大类',
					'交通运输大类', '轻纺食品大类', '电子信息大类',
					'公共事业大类', '生化与药品大类', '艺术设计传媒大类',
					'资源开发与测绘大类', '环保、气象与安全大类'

				],
				index1: 0,
				index3: 0,
				array3: ['群众', '团员', '党员'],
				array2: [
					'请选择', '贵阳市', '遵义市', '六盘水市', '安顺市', '毕节市', '铜仁市',
					'黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州'

				],
				index2: 0
			}
		},

		methods: {
			finish() {
				if (this.index1 == 0) {
					uni.showToast({
						icon: "error",
						title: "请选择专业大类",
						duration: 2000
					})
					return
				} else if (this.index2 == 0) {
					uni.showToast({
						icon: "error",
						title: "请选择所在城市",
						duration: 2000

					})
					return
				} else if (this.gender_ == '') {
					uni.showToast({
						icon: "error",
						title: "请选择性别",
						duration: 2000
					})
					return
				}

				uni.navigateTo({
					url: '/pages/register/register3?account_number=' + this.account_number_ + '&psw=' + this.psw_ +
						'&name=' + this.name_ + '&major=' + this.major_ + '&politicalFace=' + this.politicalFace_ +
						'&home=' + this.home_ + '&gender=' + this.gender_
				})

			},
			bindPickerChange3(e) {
				this.index3 = e.detail.value
				this.politicalFace_ = this.array3[this.index3]
			},
			bindPickerChange2: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index2 = e.detail.value
				this.home_ = this.array2[this.index2]



			},
			bindPickerChange1: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index1 = e.detail.value
				this.major_ = this.array1[this.index1]
			},
			in_gender(e) {
				this.gender_ = e.detail.value
			},
			// finish() {
			// 	uni.navigateTo({
			// 		url: '/pages/register/register3'
			// 	})
			// }

		}
	}
</script>

<style>
	.all-size {
		margin-top: 37px;
	}

	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}

	/* 	.nvue-page-root {
		background-color: #F8F8F8;
		padding-bottom: 100%;
	} */

	/* 	
	.page-title {

	    display: flex;

	    flex-direction: row;
	    justify-content: center;
	    align-items: center;
	    padding: 35rpx;
	}
	 */
	/* 	.page-title__wrapper {
	    padding: 0px 20px;
	    border-bottom-color: #D8D8D8;
	    border-bottom-width: 1px;
	} */

	/* 	.page-title__text {
	    font-size: 16px;
	    height: 48px;
	    line-height: 48px;
	    color: #BEBEBE;
	}
	 */
	.title {
		padding: 5px 10px;
	}

	/* 	.uni-form-item__title {
	    font-size: 16px;
	    line-height: 24px;
	}
	 */
	/* 	.uni-input-wrapper {

	    display: flex;

	    padding: 8px 13px;
	    flex-direction: row;
	    flex-wrap: nowrap;
	    background-color: #FFFFFF;
	} */

	.uni-input {
		height: 28px;
		line-height: 28px;
		font-size: 15px;
		padding: 0px;
		flex: 1;
		background-color: #FFFFFF;
	}

	/* 	.uni-icon {
	    font-family: uniicons;
	    font-size: 24px;
	    font-weight: normal;
	    font-style: normal;
	    width: 24px;
	    height: 24px;
	    line-height: 24px;
	    color: #999999;
	} */

	/* 	.uni-eye-active {
	    color: #007AFF;
	} */

	/* 	.uni-input {
		line-height: 25px;
		margin-left: 0;
	} */

	.gender {
		margin-left: 20px;
	}

	button {
		margin-top: 30rpx;
		margin-bottom: 30rpx;
	}

	.button-register {
		margin: 0 auto;
		width: 60%;
	}

	.uni-input-picker {
		line-height: 43px;
		text-align: center;
		background-color: ;
		/* filter: drop-shadow(); */
	}

	.login_from_input {
		width: 100%;
		height: auto;
		/* 		display: flex; */
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		/* 		border-bottom: 1px #eee solid; */
		/* 		padding: 40upx 0px; */
		margin: 0px auto;
	}

	.register-next-button {
		width: 30%;
		margin: auto;
	}
</style>
