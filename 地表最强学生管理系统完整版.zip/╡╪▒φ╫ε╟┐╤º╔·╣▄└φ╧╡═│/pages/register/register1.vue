<template>
	<view class="container">
		<!-- 设置背景图片 -->
		<image class="bg-img" src="/static/bg.png"></image>
		<view class="content"></view>
		<view class="all-size">
			<form @submit="formSubmit">
				<view class="login_from_input">			
					<view>姓名：</view>
					<view><input type="text" name="nickname" @input="in_name" placeholder="请输入姓名" placeholder-style="color:#fff"></view>
				</view>
				<view class="login_from_input">
					<view>学号：</view>
					<view class="account-number">{{this.account_number_}}</view>
				</view>
				<view class="login_from_input">
					<view>密码：</view>
					<view ><input type="password" @input="in_psw" placeholder="请输入密码" placeholder-style="color:#fff"></view>
				</view>
				<view class="login_from_input">
					<view>确认密码：</view>
					<view><input type="password" @input="in_psw1" placeholder="请再次输入密码" placeholder-style="color:#fff"></view>
				</view>
				<br>
				<view class="register-next-button">
					<button form-type="submit" @click="finish" type="primary">下一步</button>
				</view>
				
			</form>
		</view>
	</view>

</template>

<script>
	export default{
		data(){
			return{
				account_number_:'',
				psw_:'',
				psw_1:'',
				name_:''
			}
		},
		onLoad(option) {
			this.account_number_=option.account_number
		},
		methods:{
			finish() {
				if(this.name_=="")
				{
					uni.showToast({
						icon:"error",
						title:"姓名不能为空",
						duration:2000
					})
					return
				}else if(this.psw_==""){
					uni.showToast({
						icon:"error",
						title:"密码不能为空",
						duration:2000
					})
					return
				}else if(this.psw_!=this.psw_1){
					uni.showToast({
						icon:"error",
						title:"密码输入不一致",
						duration:2000
					})
					return
				}
				uni.navigateTo({
					url:'/pages/register/register2?account_number='+this.account_number_+'&psw='+this.psw_+'&name='+this.name_
				})
			},
			in_psw(e)
			{
				this.psw_=e.target.value
			},
			in_psw1(e){
				this.psw_1=e.target.value
			},
			in_name(e)
			{
				this.name_=e.detail.value
			}
							
		}
	}
</script>

<style>
	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}
	
	.all-size{
		margin-top: 80px;
	}
	

	.register-next-button{
		width: 30%;
		margin: auto;
	}
	
	.login_from_input{ 
		width: 100%;
		 height:auto; 
		 display: flex;
		 flex-direction: row;
		 justify-content: space-between;
		 align-items: center;
		 border-bottom: 1px #eee solid;
		 padding: 40upx 0px;
		 margin: 0px auto;
	}
	
	.account-number{
		margin: auto;
	}
</style>
