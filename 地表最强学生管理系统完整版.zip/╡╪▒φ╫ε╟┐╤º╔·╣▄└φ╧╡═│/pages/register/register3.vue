<template>
	<view class="page">
		<image src="/static/bg.png" class="bg-img"></image>
		<view class="question_input">
			<image src="../../static/问题(2).png" class="icon_size"></image>
			<view>密保问题：</view>
			<view><input type="text" @input="input_ques" v-model="ques_" placeholder="请输入密保问题"
					placeholder-style="color:white"></view>
		</view>

		<view class="question_input">
			<image src="../../static/正确答案-04.png" class="icon_size"></image>
			<view>密保答案：</view>
			<view><input type="text" @input="input_ans" v-model="ans_" placeholder="请输入问题答案"
					placeholder-style="color:white"></view>
		</view>
		<button type="primary" class="button_set" @click="question_submit">提交</button>
	</view>

</template>

<script>
	export default {
		data() {
			return {
				name_: '',
				psw_: '',
				account_number_: '',
				politicalFace_: '',
				home_: '',
				major_: '',
				gender_: '',
				ques_: '',
				ans_: ''
			}
		},

		onLoad(option) {
			this.account_number_ = option.account_number
			this.psw_ = option.psw
			this.name_ = option.name
			this.politicalFace_ = option.politicalFace
			this.home_ = option.home
			this.major_ = option.major
			this.gender_ = option.gender

		},
		methods: {
			input_ques(e) {
				this.ques_ = e.target.value

			},
			input_ans(e) {
				this.ans_ = e.target.value
			},

			question_submit() {
				if (this.ques_ == '' || this.ans_ == '') {
					uni.showToast({
						title: "请完善信息",
						duration: 2000,
						icon: "error"
					});
					return;
				}

				let this_ = this
				uni.showModal({
					title: '提示',
					content: '确认信息输入无误',
					complete: function(res) {
						if (res.confirm) {
							console.log('用户点击确定');
							uni.request({
								url: 'http://127.0.0.1:10086/user/registerService1',
								data: {
									account_number: this_.account_number_,
									psw: this_.psw_,
									name: this_.name_,
									gender: this_.gender_,
									home: this_.home_,
									major: this_.major_,
									politicalFace: this_.politicalFace_,
									ques: this_.ques_,
									ans: this_.ans_,
								},
								success(res) {
									console.log(res)
									uni.showToast({
										icon: "success",
										title: "注册成功！",
										duration: 2000
									})

									setTimeout(() => {
										uni.navigateTo({
											url: '/pages/index/index'
										})
									}, 2000)
								},
								fail(res) {
									uni.showModal({
										title: '注册失败',
										content: res,
										showCancel: false,
										confirmText: '确定'
									})
								}
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				})
			}
		},
	}
</script>

<style>
	.page {
		margin-top: 80px;
		width: 100%;
		height: auto;
		box-sizing: border-box;
		padding: 20upx 8%;
	}

	.question_input {
		width: 100%;
		height: auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1px #eee solid;
		padding: 40upx 0px;
		margin: 0px auto;
	}

	.icon_size {
		width: 50upx;
		height: 50upx;
	}

	.button_set {
		margin-right: 5upx;
		margin-top: 50upx;
		width: 30%;
		border-radius: 20%;

	}

	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}
</style>
