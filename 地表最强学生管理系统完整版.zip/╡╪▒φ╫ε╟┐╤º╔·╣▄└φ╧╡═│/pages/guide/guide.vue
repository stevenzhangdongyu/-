<template>
	<view class="main">
		<view class="top">
			<view class="title">
				<view class="text_left"></view>
				<view class="text_right">
					迎新公告
				</view>
			</view>
		</view>




		<view class="a_list">
			<view class="item" @click="tiaozhuan()">
				<view class="item_left">

					<image class="picture" src="../../static/迎新1.png" mode="heightFix"></image>
					
					<view class="item_left_main_title" >
						温馨提示
					</view>
						
				</view>
				<image class="item_right" src="../../static/箭头.png" mode=""></image>
			</view>
			<view class="item" @click="tiaozhuan1()">
				<view class="item_left">

					<image class="picture" src="../../static/贵州学院.png" mode="heightFix"></image>

					<view class="item_left_main_title">
						贵州轻工职业技术学院
					</view>
				</view>
				<image class="item_right" src="../../static/箭头.png" mode=""></image>
			</view>
			<view class="item" @click="tiaozhuan2()">
				<view class="item_left">

					<image class="picture" src="../../static/迎新3.png" mode="heightFix"></image>

					<view class="item_left_main_title">
						关于2022-2023学年第一学期开学返校的通知
					</view>
				</view>
				<image class="item_right" src="../../static/箭头.png" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			tiaozhuan() {
				uni.navigateTo({
					url: "/pages/guide1/guide1"
				})
			},
			tiaozhuan1() {
				uni.navigateTo({
					url: "/pages/guide1/guide2"
				})
			},
			tiaozhuan2() {
				uni.navigateTo({
					url: "/pages/guide1/guide3"
				})
			}
		

		}
	}
</script>

<style>
	.main {
			    /* display: flex; */
		    /* align-items: flex-start; */
		   /* justify-content: center; */
		background-color: #f1f5f8;
		padding-top: 15px;
		/* padding-bottom: -10px; */
	}

	.top {
		width: 100%;
		border-bottom: 1px solid #E3E9F3;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.title {
				display: flex;
		align-items: center;
		justify-content: center;
			  /*  margin: 32px 0 24px; */
	}

	.text {
		height: 30px;
	}

	.text_left {
		width: 6px;
		height: 20px;
		background: #184EA3;
		
	}

	.text_right {
		font-size: 20px;
		font-family: MicrosoftYaHei;
		color: #184ea3;
		margin-left: 8px;
		
	}

	.item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-bottom: 28px;
		margin-top: 28px;
		border-bottom: 1px dashed #E3E9F3;
		width: 100%;
	}

	.item_left {
		width: 90%;
		display: flex;
		align-items: center;
		justify-content: flex-start;
	}

	.picture {
		max-width: 160px;
		min-width: 200px;
		/* 	max-height: 80px;
	min-height:80px; */
		height: 120px;
		border-radius: 16px;
		object-fit: cover;
	}

	/* 	.item_left_main {
		font-size: 16px;
		max-width: 60%;
		font-family: MicrosoftYaHei;
		color: #184ea3;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		flex-direction: column;
		align-items: flex-start;
	} */

	.item_left_main_title {
		color: #262d3d;
		align-items: center;
		justify-content: flex-start;
		flex-direction: column;
		font-size: 16px;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		display: -webkit-box;
		text-overflow: ellipsis;
		overflow: hidden;
	}

	.item_right {
		width: 18px;
		height: 18px;
		margin-right: 0;
	}
</style>
