<template>
	<view class="page">
		<image src="../../static/8.jpg" class="bg-img"></image>
			<view class="question_input">			
				<image src="../../static/学号管理.png" class="icon_size"></image>
				<view>学号：</view>
				<view><input type="number"  @input="input_number" maxlength="8"  v-model="number"   placeholder="请输入学号" placeholder-style="color:white"></view>
			</view>
		<button  class="button_set" @click="number_submit">下一步</button>	
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				number:'',
				
			}
		},
		
		
		methods: {
			
			input_number(e){
				this.number=e.target.value
				
			},
			
			number_submit()
			{
				let reg = /^[2][0][2][2][0-9]{4}$/
				if(this.number==""){
					uni.showToast({
						title:"请输入学号", 
						duration: 2000,
						icon:"error"
					});
					return;
										
				}
				uni.request({
					url:'http://127.0.0.1:10086/user/returnQues',
					data:{
						account_number:this.number
					},
					success: (res) => {
						if(res.data['code']==1){
							uni.navigateTo({
								url:'/pages/fgt_psw/page4?ques='+res.data['ques']+'&account_number='+this.number
							})
						}else{
							uni.showToast({
								icon:"error",
								title:"用户不存在",
								duration:2000
							})
						}
					}
				})
				
			}
			
		}
	}
</script>

<style>	
	
	.page{ 
		width: 100%; 
	height: auto; 
	box-sizing: border-box; 
	padding: 20upx 8%;
	 }
	
	.question_input{ 
		width: 100%;
		 height:auto; 
		 display: flex; 
		 flex-direction: row; 
		 justify-content: space-between; 
		 align-items: center; 
		 border-bottom: 1px #eee solid;
		  padding: 40upx 0px; 
		  margin: 0px auto; 		  
		   } 
	.icon_size
	{
		width: 50upx;
		height: 50upx;
	}
	.button_set{
		margin-right: 5upx;
		margin-top: 50upx;
		width: 30%;
		background-color: aliceblue;
		border-radius: 50%;
	
	}
	.bg-img{
	    position: fixed;
	    width: 100%;
	    height: 100%;
	    top: 0;
	    left: 0;
	    z-index: -1;
	}

</style>
