<template>
	<view class="page">
		<image src="../../static/8.jpg" class="bg-img"></image>
			<view class="question_input">			
				<image src="../../static/问题(2).png" class="icon_size"></image>
				<view>密保问题：{{this.ques_}}</view>
			</view>
			
			<view class="question_input">
				<image src="../../static/正确答案-04.png" class="icon_size"></image>
				<view>密保答案：</view>
				<view ><input type="text" @input="input_answer" v-model="input_answer" placeholder="请输入问题答案" placeholder-style="color:white"></view>
			</view>	
		<button  class="button_set" @click="question_submit">完成</button>
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				ques_:'',
				input_answer:'',
				account_number_:''
				
			}
		},
		
		
		onLoad(option) {
			this.ques_=option.ques
			this.account_number_=option.account_number
		},
		methods: {
			input_answer(e)
			{
				this.input_answer=e.target.value
			},
			
			question_submit()
			{
				if(this.input_answer=="")
				{
					uni.showToast({
						title:"请填写答案", 
						duration: 2000,
						icon:"error"
					});
					return;
										
				}
				uni.request({
					url:'http://127.0.0.1:10086/user/forgetPsw',
					data:{
						ans:this.input_answer,
						account_number:this.account_number_
					},
					success: (res) => {
						if(res.data['code']==1){
							uni.showToast({
								icon:"success",
								title:"密码重置为123456",
								duration:2000
							})
							
							setTimeout(()=>{
								uni.navigateTo({
									url:'/pages/index/index'
								})
							},2000)
						}else{
							uni.showToast({
								icon:"error",
								title:"答案错误",
								duration:2000
							})
						}
					}
				})
				
			}
			
		}
	}
</script>

<style>	
	
	.page{ 
		width: 100%; 
	height: auto; 
	box-sizing: border-box; 
	padding: 20upx 8%;
	 }
	
	.question_input{ 
		width: 100%;
		 height:auto; 
		 display: flex; 
		 flex-direction: row; 
		 /* justify-content: space-between; */
		 align-items: center; 
		 border-bottom: 1px #eee solid;
		  padding: 40upx 0px; 
		  margin: 0px auto; 		  
		   } 
	.icon_size
	{
		width: 50upx;
		height: 50upx;
	}
	.button_set{
		margin-right: 5upx;
		margin-top: 50upx;
		width: 30%;
		background-color: aliceblue;
		border-radius: 50%;
	
	}
	.bg-img{
	    position: fixed;
	    width: 100%;
	    height: 100%;
	    top: 0;
	    left: 0;
	    z-index: -1;
	}

</style>
