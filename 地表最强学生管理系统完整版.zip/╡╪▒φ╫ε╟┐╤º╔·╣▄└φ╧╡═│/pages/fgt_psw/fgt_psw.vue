<template>
	<view class="container">
		<!-- 设置背景图片 -->
		<image class="bg-img" src="/static/bg.png"></image>
		<view class="content"></view>
		<form @submit="formSubmit"></form>
			<view class="fgt-psw-input">
				<view>学号：</view>
				<view><input type="number" v-model="account_number_" @input="in_number" placeholder="请输入学号" placeholder-style="color:#fff"></view>
			</view>
			<br>
			<view class="fgt-psw-button">
				<button form-type="submit" @click="finish" type="primary">查找</button>
			</view>
		</form>
	</view>
</template>

<script>
	export default{
		data(){
			return {
				account_number_:''
			}
		},
		methods:{
			finish(){
				if(account_number_==""){
					uni.showToast({
						icon:"error",
						title:"请输入学号",
						duration:2000
					})
					return
				}else{
					uni.request({
						url:'http://127.0.0.1:10086/user/returnQues',
						data:{
							account_number:this.account_number_
						},
						success:(res)=> {
							if(res.data['code']==1){
								uni.navigateTo({
									url:'/pages/fgt_psw/fgt_psw1?ques='+res.data['data']['ques']
								})
							} 
						},
						fail(res){
							uni.showToast({
								icon:"error",
								title:"该用户不存在",
								duration:2000
							})
						}
					})
				}
			},
			in_number(e){
				this.account_number_=e.detail.value
			}
		}
	}
</script>

<style>
	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}
	
	.fgt-psw-input{
		width: 100%;
		 height:auto; 
		 display: flex;
		 flex-direction: row;
		 justify-content: space-between;
		 align-items: center;
		 border-bottom: 1px #eee solid;
		 padding: 40upx 0px;
		 margin-top: 50px;
	}
	
	.fgt-psw-button{
		width: 30%;
		margin: auto;
	}
</style>