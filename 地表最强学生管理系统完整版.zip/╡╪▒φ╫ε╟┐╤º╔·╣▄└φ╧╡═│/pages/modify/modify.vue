<template>
	<view class="container">

		<image class="bg-img" src="/static/bg.png"></image>
		<view class="content"></view>
		<view class="all-size">
			<form @submit="formSubmit">
				<view class="uni-common-mt">
					<view class="login_from_input">
						<view class="title">专业大类：</view>
						<picker mask-style="background:#ffffff00;z-index:0;" @change="bindPickerChange1" :value="index1"
							:range="array1">
							<view class="uni-input-picker">{{array1[index1]}}</view>
						</picker>
					</view>
				</view>

				<view class="title">政治面貌：</view>
				<picker @change="bindPickerChange4" :value="index4" :range="array4">
					<view class="uni-input-picker">{{array4[index4]}}</view>
				</picker>
				<view class="title">所在城市：</view>
				<picker @change="bindPickerChange2" :value="index2" :range="array2">
					<view class="uni-input-picker">{{array2[index2]}}</view>
				</picker>
				
				<view class="title">性别：</view>
				<picker @change="bindPickerChange3" :value="index3" :range="array3">
					<view class="uni-input-picker">{{array3[index3]}}</view>
				</picker>
				
				<view class="question_input">
					<view>密保问题：</view>
					<view><input type="text" @input="input_ques" v-model="ques_"></view>
				</view>
				
				<view class="question_input">
					<view>密保答案：</view>
					<view><input type="text" @input="input_ans" v-model="ans_"></view>
				</view>
				<view class="register-next-button">
					<button form-type="submit" type="primary" @click="finish">提交</button>
				</view>
			</form>
		</view>
	</view>
				
</template>

<script>
	export default {
		data() {
			return {
				politicalFace: '',
				account_number_: '',
				psw_: '',
				name_: '',
				home_: '',
				major_: '',
				gender_: '',
				ques_:'',
				ans_:'',
				index1: 0,
				index4: 0,
				array4: ['群众', '团员', '党员'],
				index2: 0,
				index3: 0,
				array3: ['男', '女'],
				array1: [
					'请选择',
					'旅游大类', '财经大类', '制造大类', '土建大类',
					'交通运输大类', '轻纺食品大类', '电子信息大类',
					'公共事业大类', '生化与药品大类', '艺术设计传媒大类',
					'资源开发与测绘大类', '环保、气象与安全大类'

				],

				array2: [
					'请选择', '贵阳市', '遵义市', '六盘水市', '安顺市', '毕节市', '铜仁市',
					'黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州'

				]

			}
		},
		methods: {
			bindPickerChange3(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index3 = e.detail.value
				this.gender_ = this.array3[this.index3]
			},
			bindPickerChange4(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index4 = e.detail.value
				this.politicalFace = this.array4[this.index4]
			},
			finish() {
				if (this.ques_ == '' || this.ans_ == '') {
					uni.showToast({
						title: "密保信息不能为空",
						duration: 1000,
						icon: "error"
					});
					return;
				}

				let this_ = this

				uni.showModal({
					title: '提示',
					content: '确认信息输入无误',
					complete: function(res) {
						if (res.confirm) {
							console.log('用户点击确定');
							uni.request({
								url: 'http://127.0.0.1:10086/user/changeInformation',

								data: {

									account_number: this_.account_number_,
									name: this_.name_,
									major: this_.major_,
									home: this_.home_,
									gender: this_.gender_,
									politicalFace: this_.politicalFace,
									ques:this_.ques_,
									ans:this_.ans_
								},
								
								success(res) {
									uni.showToast({
										icon:"success",
										title:"修改成功",
										duration:2000
									})
									console.log(res)
									
									setTimeout(()=>{
										uni.navigateTo({
											url: '/pages/index/index'
										})
									},1000)
									
								}
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				});
			},

			bindPickerChange1: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index1 = e.detail.value
				this.major_ = this.array1[this.index1]
			},
			bindPickerChange2: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index2 = e.detail.value
				this.home_ = this.array2[this.index2]



			},

			in_gender(e) {
				this.gender_ = e.detail.value
			},
			in_acc(e) {
				this.account_number_ = e.detail.value
			},
			in_psw(e) {
				this.psw_ = e.detail.value
			},
			in_name(e) {
				this.name_ = e.detail.value
			},
			input_ques(e) {
				this.ques_ = e.target.value
			
			},
			input_ans(e) {
				this.ans_ = e.target.value
			}

		},
		onLoad(option) {
			this.name_ = option.name
			this.account_number_ = option.account_number
			this.major_ = option.major
			this.home_ = option.home
			this.gender_ = option.gender
			this.politicalFace = option.politicalFace
			//this.index1=2
			//let this_=this
			for (let i = 0; i < this.array4.length; i++) {
				if (this.array4[i] == this.politicalFace) {
					this.index4 = i
				}
			}
			for (let i = 0; i < this.array3.length; i++) {
				if (this.array3[i] == this.gender_) {
					this.index3 = i;
				}
			}
			for (let i = 0; i < this.array1.length; i++) {

				if (this.array1[i] == this.major_) {
					this.index1 = i;

				}
			}
			for (let j = 0; j < this.array2.length; j++) {
				if (this.array2[j] == this.home_) {
					this.index2 = j
				}
			}
		}
	}
</script>

<style scoped>
	.question_input {
		width: 100%;
		height: auto;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		padding: 40upx 0px;
		margin: 0px auto;
	}
	
	.all-size {
		margin-top: 37px;
	}

	.bg-img {
		position: fixed;
		width: 100%;
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
	}

	/* 	.nvue-page-root {
		background-color: #F8F8F8;
		padding-bottom: 100%;
	} */

	/* 	
	.page-title {

	    display: flex;

	    flex-direction: row;
	    justify-content: center;
	    align-items: center;
	    padding: 35rpx;
	}
	 */
	/* 	.page-title__wrapper {
	    padding: 0px 20px;
	    border-bottom-color: #D8D8D8;
	    border-bottom-width: 1px;
	} */

	/* 	.page-title__text {
	    font-size: 16px;
	    height: 48px;
	    line-height: 48px;
	    color: #BEBEBE;
	}
	 */
	.title {
		padding: 5px 10px;
	}

	/* 	.uni-form-item__title {
	    font-size: 16px;
	    line-height: 24px;
	}
	 */
	/* 	.uni-input-wrapper {

	    display: flex;

	    padding: 8px 13px;
	    flex-direction: row;
	    flex-wrap: nowrap;
	    background-color: #FFFFFF;
	} */

	.uni-input {
		height: 28px;
		line-height: 28px;
		font-size: 15px;
		padding: 0px;
		flex: 1;
		background-color: #FFFFFF;
	}

	/* 	.uni-icon {
	    font-family: uniicons;
	    font-size: 24px;
	    font-weight: normal;
	    font-style: normal;
	    width: 24px;
	    height: 24px;
	    line-height: 24px;
	    color: #999999;
	} */

	/* 	.uni-eye-active {
	    color: #007AFF;
	} */

	/* 	.uni-input {
		line-height: 25px;
		margin-left: 0;
	} */

	.gender {
		margin-left: 20px;
	}

	button {
		margin-top: 30rpx;
		margin-bottom: 30rpx;
	}

	.button-register {
		margin: 0 auto;
		width: 60%;
	}

	.uni-input-picker {
		line-height: 43px;
		text-align: center;
		background-color: ;
		/* filter: drop-shadow(); */
	}

	.login_from_input {
		width: 100%;
		height: auto;
		/* 		display: flex; */
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		/* 		border-bottom: 1px #eee solid; */
		/* 		padding: 40upx 0px; */
		margin: 0px auto;
	}

	.register-next-button {
		width: 30%;
		margin: auto;
	}
</style>
