<template>
	<form action="">
		<view class="con_tit">
			<h1 style="color:#003c74;font-size:24px;">开学啦！学院顺利迎来2022年春季学期返校学生</h1>
		</view>
		<view class="content">
			<p class="content" style="font-size: 16px; line-height: 32px;">追梦奋斗正当时，不负春光再出发。2月26日、2月27日及3月4日，学院迎来2022年春季学期分批错峰返校学生。</p>
			<image class="picture" src="../../static/返校1.jpg" mode=""></image>
			<p class="content" style="font-size: 16px; line-height: 32px;">为确保新学期按时、顺利、有序开学。学生返校前夕，学院党委高度重视，科学统筹，精心谋划，制定《贵州轻工职业技术学院2022年春季学期学生开学返校现场工作方案》，按照“分批、错峰、有序”的原则，采取有力措施，扎实抓好开学前准备工作，营造了安全、稳定、温馨的开学环境。</p>
			<p class="content" style="font-size: 16px; line-height: 32px;">2月26日，学院党委书记樊铁钢等院领导来到报到现场，检查指导疫情防控及开学相关工作，看望返校学生，慰问在寒风中坚守一线的工作人员和志愿者。</p>
			<image  class="picture" src="../../static/返校2.jpg" mode=""></image>
			<image  class="picture" src="../../static/返校3.jpg" mode=""></image>
			<image  class="picture" src="../../static/返校4.jpg" mode=""></image>
			<image  class="picture" src="../../static/返校5.jpg" mode=""></image>
			<image  class="picture" src="../../static/返校6.jpg" mode=""></image>
			<image  class="picture" src="../../static/返校7.jpg" mode=""></image>
			<p class="content" style="font-size: 16px; line-height: 32px;">报到现场秩序井然，方便快捷。学院在校门口搭建了防风通道，开设了四条专用查验通道。同学们在工作人员的指引和帮助下，依次严格完成了体温测量、消杀和健康码、行程卡、核酸检测证明查验等流程后顺利进入校园。此外，学院还组织辅导员、学生志愿者、校园摆渡车在现场提供口罩发放、行李搬运及输送等暖心服务。相关部门工作人员以高度负责、严谨认真的态度精准落实好每个环节，确保开学工作万无一失，顺利迎接同学们返校。</p>
			<p class="content" style="font-size: 16px; line-height: 32px;">“高楼晓见一花开，便觉春光四面来。”校园里嫩黄的迎春花、盛开的梅花、鉴池畔招摇的垂柳都似在向同学们热情诉说“春天到啦，欢迎回家！”</p>
			<p class="content" style="font-size: 16px; line-height: 32px;">据悉，按照常态化疫情防控工作相关要求，学院在学生返校后将进一步加强教育管理、落实日常防控，精心组织好“开学第一课”，保障学生返校后的正常教学秩序，确保统筹有序、有力有效推动学院疫情防控和事业发展各项工作。</p>
		</view>
	</form>
</template>

<script>
</script>

<style>
	.con_tit{
		    text-align: center;
		    padding-bottom: 16px;
	}
	.content {
		font-size: 18px;
		/* padding-bottom: 16px;
		overflow: hidden; */
		text-indent:20px;
	}
	.picture{
		text-align: center;
		    text-indent: 0;
			width: 100%;
	}
	
	
</style>