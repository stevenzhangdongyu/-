	 <template>
	<view class="detail">
		<view class="top">
			<view class="title">
				<view class="title_left"></view>
				<view class="title_right">迎新公告</view>
			</view>
			
		</view>
		<view class="content">
			<view class="text-align">
				<image  class="style" src="../../static/公告.png" @tap="_previewImage(info.shopLogoUrl)" mode=""></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		methods:{
				_previewImage(image) {
							var imgArr = '';
							imgArr.push(image);
							//预览图片
							uni.previewImage({
								urls: imgArr,
								current: imgArr,
							});
						},
		}
	}
</script>

<style>
	.detail{
		    z-index: 99;
		/*    width: 60%; */
		/* 	height: 100%; */
		    background: #FFFFFF;
		    box-shadow: 0 0 8px #e9eef5;
		    margin-top: 0px;
		    padding: 0 32px 32px;
		    display: flex;
		    align-items: center;
		    justify-content: flex-start;
		    flex-direction: column;
	}
	.title{
		    display: flex;
		    align-items: center;
		    justify-content: center;
		    margin: 32px 0 24px;
	}
	.title_left{
		    width: 6px;
		    height: 20px;
		    background: #184EA3;
	}
	.title_right{
		font-size: 20px;
		    font-family: MicrosoftYaHei;
		    color: #184ea3;
		    margin-left: 8px;
	}
	.content{
		width: 100%;
		    white-space: pre-wrap;
		    margin-top: 32px;
		    text-align: center;
	}
	.text-align{
		    padding: 0;
		    margin: 0;
		    list-style: none;
		    font-style: normal;
		    text-decoration: none;
		    border: none;
		    box-sizing: border-box;
		    font-family: Microsoft Yahei,sans-serif;
		    -webkit-tap-highlight-color: transparent;
		    -webkit-font-smoothing: antialiased;
	}
	.style{
		    max-width: 70%;
		    vertical-align: top;
		    margin: 0px auto;
	}
</style>