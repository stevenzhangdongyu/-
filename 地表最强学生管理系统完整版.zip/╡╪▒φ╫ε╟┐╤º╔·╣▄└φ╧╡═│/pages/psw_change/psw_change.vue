<template>
	<view class="nvue-page-root">
        <view class="page-title">
            <view class="page-title__wrapper">
                <!-- <text class="page-title__text">{{title}}</text> -->
            </view>
        </view>	
		
		 <view class="answer_input">
			 <image src="../../static/密码锁(1).png" class="icon_size"></image>
		<view>原密码:</view>
		<view><input type="password" @input="in_psw_before"  placeholder="请输入原密码" placeholder-style="color:grey" ></view>
		</view>
		
		<view class="answer_input">
			 <image src="../../static/密码锁.png" class="icon_size"></image>
		<view class="text_content">新密码：</view>
		<view><input type="password" @input="in_psw_new"  placeholder="请输入新密码" placeholder-style="color:grey" ></view>
		</view>
		
		<view class="answer_input">
			 <image src="../../static/再次输入密码(1).png" class="icon_size"></image>
		<view>新密码：</view>
		<view><input type="password" @input="in_psw_confirm"  placeholder="请再次输入新密码" placeholder-style="color:grey" ></view>
		</view>
		
		<button  class="button_set"  @click="sub">提交</button>
		
	</view>
</template>

<script>
    export default {
		onLoad(option) {
			this.psw_before=option.psw;
			//console.log(option.psw);
			this.acc=option.account_number;
			//console.log(option.account_number);
		},
        data() {
			
            	return {
					psw_before:'',
					psw_before_in:'',
					psw_new:'',
					psw_new_con:'',
					acc:'',
            		changePwdDialog:false,//修改密码弹框
            		ruleForm: {
            			newPwd: '',
            			confirmPwd:''
            		},
            		rules: {
            			newPwd: [
            			{ required: true, message: '请输入密码', trigger: 'blur' },
            			{ min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: 'blur' },
            			{ validator: validatePass, trigger: 'blur' }
            			],
            			confirmPwd:[
            			{ required: true, message: '请确认密码', trigger: 'blur' },
            			{ min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: 'blur' },
            			{ validator: validatePass2, trigger: 'blur', required: true }
            			],
            		}
            	}
            
        },
        methods: {
			sub()
			{
				if(this.psw_before==this.psw_before_in)
				{
					if(this.psw_new==this.psw_new_con)
					{
						uni.showToast({
							icon:"success",
							title:"修改成功",
							duration:2000
						})
						
						setTimeout(()=>{
							uni.request({
								url:'http://127.0.0.1:10086/user/changePswService?account_number='+this.acc+'&psw='+this.psw_before+'&new_psw='+this.psw_new_con,
								// data:{
								// 	account_number:this.acc,
								// 	psw:this.psw_before,
								// 	new_psw:this.psw_new_con
								// },
								success(res) {
									uni.navigateTo({
										url:'/pages/index/index'
									})
								}
							})
						},1000)
						// this.psw_new_con=this.psw_new_con
						
					}else{
						uni.showToast({
							icon:"error",
							title:"两次密码不一致",
							duration:2000
						})
					}
				}else{
					uni.showToast({
						icon:"error",
						title:"原密码输入错误",
						duration:2000
					})
				}
			},
			in_psw_before(e)
			{
				this.psw_before_in=e.detail.value
				
			},
			in_psw_new(e)
			{
				this.psw_new=e.detail.value
				
			},
			in_psw_confirm(e)
			{
				this.psw_new_con=e.detail.value
			},
			// bindPickerChange: function(e) {
			// 	console.log('picker发送选择改变，携带值为：' + e.detail.value)
			// 	this.index = e.detail.value
			// },
			formSubmit: function(e) {
				console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
			    
			    var rule = [
			        {name:"password", checkType : "number", checkRule:"6,16",  errorMsg:"密码应为6-10位数字"},
			        
			        
			    ];
			    //检查
			    // var formData = e.detail.value;
			    // var checkRes = graceChecker.check(formData, rule);
			    // if(checkRes){
			    //     uni.showToast({title:"修改成功!", icon:"none"});
			    // }else{
			    //     uni.showToast({ title: graceChecker.error, icon: "none" });
			    // }
			}
		}
    }
</script>

<style scoped>

    .page-title {
        /* #ifndef APP-NVUE */
        display: flex;
        /* #endif */
        flex-direction: row;
        justify-content: center;
        align-items: center;
        padding: 5rpx;
		
    }

    .page-title__wrapper {
        padding: 0px 20px;
        border-bottom-color: #D8D8D8;
        border-bottom-width: 1px;
    }

    .page-title__text {
        font-size: 16px;
        height: 48px;
        line-height: 48px;
        color: #BEBEBE;
    }

    .title {
        padding: 5px 10px;
    }

    .uni-form-item__title {
        font-size: 16px;
        line-height: 24px;
    }

    .uni-input-wrapper {
        /* #ifndef APP-NVUE */
        display: flex;
        /* #endif */
        padding: 8px 13px;
        flex-direction: row;
        flex-wrap: nowrap;
        background-color: #FFFFFF;
    }


	

	.gender {
		margin-left: 20px;
	}
	
	
	.answer_input{
		width: 100%;
		 height:auto; 
		 display: flex; 
		 flex-direction: row; 
		 justify-content: space-between; 
		 align-items: center; 
		 border-bottom: 1px #eee solid;
		  padding: 40upx 0px; 
		  margin: 0px auto; 		  
		   } 
	.icon_size
	{
		margin-left: 50px;
		width: 50upx;
		height: 50upx;
	}
	.button_set{
		margin-right: 50upx;
		margin-top: 50upx;
		width: 30%;
		background-color: aliceblue;
		border-radius: 30%;
	
	}
	.text_content
	{
		margin-left: 0upx;
	}
</style>
